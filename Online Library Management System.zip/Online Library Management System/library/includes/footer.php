   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy;MERU UNIVERSITY OF SCIENCE AND TECHNOLOGY |<a href="#" target="_blank"  > Designed by : THE GROUP</a> 
                </div>

            </div>
        </div>
    </section>