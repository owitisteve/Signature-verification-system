<?php
session_start(); // Start a session to manage user sessions
error_reporting(0); // Disable error reporting (suppress error messages)
include('includes/config.php'); // Include a configuration file

if ($_SESSION['alogin'] != '') { // Check if the admin is already logged in and clear the existing session
    $_SESSION['alogin'] = ''; // Clear the admin login session
}

if (isset($_POST['login'])) { // Check if the "login" form is submitted
    $username = $_POST['username']; // Get the username from the form
    $password = md5($_POST['password']); // Hash the password using MD5

    // Query to check if the provided username and password match an active admin
    $sql = "SELECT UserName, Password, Status FROM admin WHERE UserName = :username and Password = :password";
    $query = $dbh->prepare($sql);
    $query->bindParam(':username', $username, PDO::PARAM_STR);
    $query->bindParam(':password', $password, PDO::PARAM_STR);
    $query->execute();
    $results = $query->fetchAll(PDO::FETCH_OBJ);

    if ($query->rowCount() > 0) { // If there is a matching admin record
        $adminStatus = $results[0]->Status;

        if ($adminStatus == 1) { // If the admin account is active
            $_SESSION['alogin'] = $username; // Set the admin login session
            echo "<script type='text/javascript'> document.location ='admin/reg_request.php'; </script>"; // Redirect to the admin dashboard
        } else {
            echo "<script>alert('Your admin account is deactivated. Please contact the administrator.');</script>"; // Display a message if the admin account is deactivated
        }
    } else {
        echo "<script>alert('Invalid username or password');</script>"; // Display a message for invalid login details
    }
}
?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>COUNTY GOVERNMENT OF KISUMU</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css" rel="stylesheet" />

</head>
<body>
    <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
<div class="content-wrapper">
    <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">steve login</h4>
            </div>
        </div>

        <!--LOGIN PANEL START-->           
        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3" >
                <div class="panel panel-info">
                    <div class="panel-heading">
                        LOGIN FORM
                    </div>
                    <div class="panel-body">
                        <form role="form" method="post">

                            <div class="form-group">
                                <label>Enter Username</label>
                                <input class="form-control" type="text" name="username" autocomplete="off" required />
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <div class="input-group">
                                    <input class="form-control" type="password" id="password" name="password" autocomplete="off" required />
                                    <span class="input-group-addon" id="password-toggle">
                                        <i id="password-icon" class="fa fa-eye"></i>
                                    </span>
                                </div>
                                <p class="help-block"><a href="adminsignup.php">Create New Admin</a></p>
                            </div>

                            <button type="submit" name="login" class="btn btn-info">LOGIN </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>  
        <!---LOGIN PABNEL END-->            
    </div>
</div>
<!-- CONTENT-WRAPPER SECTION END-->
<?php include('includes/footer.php');?>
<!-- FOOTER SECTION END-->
<script src="assets/js/jquery-1.10.2.js"></script>
<!-- BOOTSTRAP SCRIPTS  -->
<script src="assets/js/bootstrap.js"></script>
<!-- CUSTOM SCRIPTS  -->
<script src="assets/js/custom.js"></script>
</script>
<script>
    document.getElementById("password-toggle").addEventListener("click", function () {
        var passwordInput = document.getElementById("password");
        var passwordIcon = document.getElementById("password-icon");

        if (passwordInput.type === "password") {
            passwordInput.type = "text";
            passwordIcon.classList.remove("fa-eye");
            passwordIcon.classList.add("fa-eye-slash");
        } else {
            passwordInput.type = "password";
            passwordIcon.classList.remove("fa-eye-slash");
            passwordIcon.classList.add("fa-eye");
        }
    });
</script>

</body>
</html>
